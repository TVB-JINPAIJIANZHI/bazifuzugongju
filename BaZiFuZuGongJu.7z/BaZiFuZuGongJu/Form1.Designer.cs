﻿namespace BaZiFuZuGongJu
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            buttonnz = new Button();
            buttonyz = new Button();
            buttonsz = new Button();
            button4 = new Button();
            buttonrz = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            comboBoxsz = new ComboBox();
            comboBoxrz = new ComboBox();
            comboBoxyz = new ComboBox();
            comboBoxnz = new ComboBox();
            comboBoxsg = new ComboBox();
            comboBoxrg = new ComboBox();
            comboBoxyg = new ComboBox();
            comboBoxng = new ComboBox();
            radioButtonvv = new RadioButton();
            radioButtonll = new RadioButton();
            dateTimePicker1 = new DateTimePicker();
            buttonng = new Button();
            buttonyg = new Button();
            buttonrg = new Button();
            buttonsg = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            buttonp = new Button();
            buttongj = new Button();
            buttonjin = new Button();
            buttontu = new Button();
            buttonshui = new Button();
            buttonmu = new Button();
            buttonhuo = new Button();
            buttongz = new Button();
            linkLabel1 = new LinkLabel();
            linkLabel2 = new LinkLabel();
            linkLabelntgss = new LinkLabel();
            linkLabel4 = new LinkLabel();
            linkLabel5 = new LinkLabel();
            linkLabel6 = new LinkLabel();
            linkLabencs = new LinkLabel();
            linkLabel8 = new LinkLabel();
            linkLabel9 = new LinkLabel();
            linkLabel10 = new LinkLabel();
            linkLabelytgss = new LinkLabel();
            linkLabel12 = new LinkLabel();
            linkLabel13 = new LinkLabel();
            linkLabelycs = new LinkLabel();
            linkLabel15 = new LinkLabel();
            linkLabel17 = new LinkLabel();
            linkLabelrtgss = new LinkLabel();
            linkLabel20 = new LinkLabel();
            linkLabelrcs = new LinkLabel();
            linkLabel22 = new LinkLabel();
            linkLabel23 = new LinkLabel();
            linkLabel24 = new LinkLabel();
            linkLabelstgss = new LinkLabel();
            linkLabel26 = new LinkLabel();
            linkLabel27 = new LinkLabel();
            linkLabelscs = new LinkLabel();
            linkLabel29 = new LinkLabel();
            linkLabel30 = new LinkLabel();
            linkLabel31 = new LinkLabel();
            linkLabel32 = new LinkLabel();
            linkLabel33 = new LinkLabel();
            linkLabelndzss1 = new LinkLabel();
            linkLabel35 = new LinkLabel();
            linkLabel36 = new LinkLabel();
            linkLabel37 = new LinkLabel();
            linkLabel38 = new LinkLabel();
            linkLabelydzss1 = new LinkLabel();
            linkLabel40 = new LinkLabel();
            linkLabel41 = new LinkLabel();
            linkLabel42 = new LinkLabel();
            linkLabel43 = new LinkLabel();
            linkLabel44 = new LinkLabel();
            linkLabel45 = new LinkLabel();
            linkLabel46 = new LinkLabel();
            linkLabelrdzss1 = new LinkLabel();
            linkLabel48 = new LinkLabel();
            linkLabel49 = new LinkLabel();
            linkLabel50 = new LinkLabel();
            linkLabel51 = new LinkLabel();
            linkLabel52 = new LinkLabel();
            linkLabel53 = new LinkLabel();
            linkLabel54 = new LinkLabel();
            linkLabel55 = new LinkLabel();
            linkLabel56 = new LinkLabel();
            linkLabelsdzss1 = new LinkLabel();
            linkLabel58 = new LinkLabel();
            linkLabel59 = new LinkLabel();
            linkLabel60 = new LinkLabel();
            richTextBox1 = new RichTextBox();
            linkLabel7hff = new LinkLabel();
            timer1 = new System.Windows.Forms.Timer(components);
            label1 = new Label();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button25 = new Button();
            button26 = new Button();
            button27 = new Button();
            button28 = new Button();
            button29 = new Button();
            button30 = new Button();
            button31 = new Button();
            button32 = new Button();
            button33 = new Button();
            button34 = new Button();
            button35 = new Button();
            button36 = new Button();
            button37 = new Button();
            button52 = new Button();
            button55 = new Button();
            button57 = new Button();
            button58 = new Button();
            button61 = new Button();
            button62 = new Button();
            button63 = new Button();
            button65 = new Button();
            button54 = new Button();
            button56 = new Button();
            linkLabel25 = new LinkLabel();
            button59 = new Button();
            checkBox1 = new CheckBox();
            numericUpDownyear = new NumericUpDown();
            numericUpDownmonth = new NumericUpDown();
            numericUpDownday = new NumericUpDown();
            numericUpDownhour = new NumericUpDown();
            linkLabel28 = new LinkLabel();
            checkBoxln = new CheckBox();
            linkLabelsdzss2 = new LinkLabel();
            linkLabelrdzss2 = new LinkLabel();
            linkLabelydzss2 = new LinkLabel();
            linkLabelndzss2 = new LinkLabel();
            linkLabellnsss = new LinkLabel();
            linkLabellnssr = new LinkLabel();
            linkLabellnssy = new LinkLabel();
            linkLabellnssn = new LinkLabel();
            linkLabel3 = new LinkLabel();
            linkLabel7 = new LinkLabel();
            linkLabel11 = new LinkLabel();
            linkLabel14 = new LinkLabel();
            linkLabel16 = new LinkLabel();
            linkLabel18 = new LinkLabel();
            linkLabel19 = new LinkLabel();
            linkLabel34 = new LinkLabel();
            linkLabel39 = new LinkLabel();
            linkLabel47 = new LinkLabel();
            linkLabel57 = new LinkLabel();
            linkLabel61 = new LinkLabel();
            linkLabel62 = new LinkLabel();
            linkLabel63 = new LinkLabel();
            linkLabel64 = new LinkLabel();
            linkLabel21 = new LinkLabel();
            linkLabel65 = new LinkLabel();
            linkLabel66 = new LinkLabel();
            linkLabel67 = new LinkLabel();
            linkLabel68 = new LinkLabel();
            linkLabel69 = new LinkLabel();
            linkLabel70 = new LinkLabel();
            linkLabel71 = new LinkLabel();
            linkLabel72 = new LinkLabel();
            linkLabel73 = new LinkLabel();
            linkLabel74 = new LinkLabel();
            linkLabel75 = new LinkLabel();
            ((System.ComponentModel.ISupportInitialize)numericUpDownyear).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownmonth).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownday).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownhour).BeginInit();
            SuspendLayout();
            // 
            // buttonnz
            // 
            buttonnz.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonnz.Location = new Point(16, 577);
            buttonnz.Name = "buttonnz";
            buttonnz.Size = new Size(40, 45);
            buttonnz.TabIndex = 0;
            buttonnz.Text = "正";
            buttonnz.UseVisualStyleBackColor = true;
            buttonnz.Click += buttonnz_Click;
            // 
            // buttonyz
            // 
            buttonyz.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonyz.Location = new Point(497, 577);
            buttonyz.Name = "buttonyz";
            buttonyz.Size = new Size(40, 45);
            buttonyz.TabIndex = 1;
            buttonyz.Text = "正";
            buttonyz.UseVisualStyleBackColor = true;
            buttonyz.Click += buttonyz_Click;
            // 
            // buttonsz
            // 
            buttonsz.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonsz.Location = new Point(1461, 577);
            buttonsz.Name = "buttonsz";
            buttonsz.Size = new Size(40, 45);
            buttonsz.TabIndex = 2;
            buttonsz.Text = "正";
            buttonsz.UseVisualStyleBackColor = true;
            buttonsz.Click += buttonsz_Click;
            // 
            // button4
            // 
            button4.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button4.Location = new Point(-1, 496);
            button4.Name = "button4";
            button4.Size = new Size(75, 36);
            button4.TabIndex = 3;
            button4.Text = "正大";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // buttonrz
            // 
            buttonrz.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonrz.Location = new Point(978, 577);
            buttonrz.Name = "buttonrz";
            buttonrz.Size = new Size(40, 45);
            buttonrz.TabIndex = 4;
            buttonrz.Text = "正";
            buttonrz.UseVisualStyleBackColor = true;
            buttonrz.Click += buttonrz_Click;
            // 
            // button6
            // 
            button6.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button6.Location = new Point(480, 694);
            button6.Name = "button6";
            button6.Size = new Size(75, 36);
            button6.TabIndex = 5;
            button6.Text = "正大";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button7.Location = new Point(961, 496);
            button7.Name = "button7";
            button7.Size = new Size(75, 36);
            button7.TabIndex = 6;
            button7.Text = "旺衰";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button8.Location = new Point(1444, 496);
            button8.Name = "button8";
            button8.Size = new Size(75, 36);
            button8.TabIndex = 7;
            button8.Text = "正大";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // comboBoxsz
            // 
            comboBoxsz.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxsz.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxsz.FormattingEnabled = true;
            comboBoxsz.Location = new Point(1849, 83);
            comboBoxsz.Name = "comboBoxsz";
            comboBoxsz.Size = new Size(50, 39);
            comboBoxsz.TabIndex = 8;
            // 
            // comboBoxrz
            // 
            comboBoxrz.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxrz.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxrz.FormattingEnabled = true;
            comboBoxrz.Location = new Point(1793, 83);
            comboBoxrz.Name = "comboBoxrz";
            comboBoxrz.Size = new Size(50, 39);
            comboBoxrz.TabIndex = 9;
            // 
            // comboBoxyz
            // 
            comboBoxyz.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxyz.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxyz.FormattingEnabled = true;
            comboBoxyz.Location = new Point(1737, 83);
            comboBoxyz.Name = "comboBoxyz";
            comboBoxyz.Size = new Size(50, 39);
            comboBoxyz.TabIndex = 10;
            // 
            // comboBoxnz
            // 
            comboBoxnz.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxnz.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxnz.FormattingEnabled = true;
            comboBoxnz.Location = new Point(1681, 83);
            comboBoxnz.Name = "comboBoxnz";
            comboBoxnz.Size = new Size(50, 39);
            comboBoxnz.TabIndex = 11;
            // 
            // comboBoxsg
            // 
            comboBoxsg.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxsg.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxsg.FormattingEnabled = true;
            comboBoxsg.Location = new Point(1849, 38);
            comboBoxsg.Name = "comboBoxsg";
            comboBoxsg.Size = new Size(50, 39);
            comboBoxsg.TabIndex = 12;
            // 
            // comboBoxrg
            // 
            comboBoxrg.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxrg.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxrg.FormattingEnabled = true;
            comboBoxrg.Location = new Point(1793, 38);
            comboBoxrg.Name = "comboBoxrg";
            comboBoxrg.Size = new Size(50, 39);
            comboBoxrg.TabIndex = 13;
            // 
            // comboBoxyg
            // 
            comboBoxyg.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxyg.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxyg.FormattingEnabled = true;
            comboBoxyg.Location = new Point(1737, 38);
            comboBoxyg.Name = "comboBoxyg";
            comboBoxyg.Size = new Size(50, 39);
            comboBoxyg.TabIndex = 14;
            // 
            // comboBoxng
            // 
            comboBoxng.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxng.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            comboBoxng.FormattingEnabled = true;
            comboBoxng.Location = new Point(1681, 38);
            comboBoxng.Name = "comboBoxng";
            comboBoxng.Size = new Size(50, 39);
            comboBoxng.TabIndex = 15;
            // 
            // radioButtonvv
            // 
            radioButtonvv.AutoSize = true;
            radioButtonvv.BackColor = Color.White;
            radioButtonvv.Checked = true;
            radioButtonvv.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            radioButtonvv.ForeColor = Color.Fuchsia;
            radioButtonvv.Location = new Point(1239, 2);
            radioButtonvv.Name = "radioButtonvv";
            radioButtonvv.Size = new Size(56, 35);
            radioButtonvv.TabIndex = 20;
            radioButtonvv.TabStop = true;
            radioButtonvv.Text = "女";
            radioButtonvv.UseVisualStyleBackColor = false;
            // 
            // radioButtonll
            // 
            radioButtonll.AutoSize = true;
            radioButtonll.BackColor = Color.White;
            radioButtonll.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            radioButtonll.ForeColor = Color.Sienna;
            radioButtonll.Location = new Point(1177, 2);
            radioButtonll.Name = "radioButtonll";
            radioButtonll.Size = new Size(56, 35);
            radioButtonll.TabIndex = 21;
            radioButtonll.Text = "男";
            radioButtonll.UseVisualStyleBackColor = false;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CustomFormat = "yyyy-MM-dd-HH";
            dateTimePicker1.Font = new Font("微软雅黑", 15F, FontStyle.Bold);
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.Location = new Point(1226, 827);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(0, 34);
            dateTimePicker1.TabIndex = 22;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // buttonng
            // 
            buttonng.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonng.Location = new Point(16, 532);
            buttonng.Name = "buttonng";
            buttonng.Size = new Size(40, 45);
            buttonng.TabIndex = 23;
            buttonng.Text = "正";
            buttonng.UseVisualStyleBackColor = true;
            buttonng.Click += buttonng_Click;
            // 
            // buttonyg
            // 
            buttonyg.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonyg.Location = new Point(497, 532);
            buttonyg.Name = "buttonyg";
            buttonyg.Size = new Size(40, 45);
            buttonyg.TabIndex = 24;
            buttonyg.Text = "正";
            buttonyg.UseVisualStyleBackColor = true;
            buttonyg.Click += buttonyg_Click;
            // 
            // buttonrg
            // 
            buttonrg.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonrg.Location = new Point(978, 532);
            buttonrg.Name = "buttonrg";
            buttonrg.Size = new Size(40, 45);
            buttonrg.TabIndex = 25;
            buttonrg.Text = "正";
            buttonrg.UseVisualStyleBackColor = true;
            buttonrg.Click += buttonrg_Click;
            // 
            // buttonsg
            // 
            buttonsg.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            buttonsg.Location = new Point(1461, 532);
            buttonsg.Name = "buttonsg";
            buttonsg.Size = new Size(40, 45);
            buttonsg.TabIndex = 26;
            buttonsg.Text = "正";
            buttonsg.UseVisualStyleBackColor = true;
            buttonsg.Click += buttonsg_Click;
            // 
            // button13
            // 
            button13.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button13.Location = new Point(-1, 622);
            button13.Name = "button13";
            button13.Size = new Size(75, 36);
            button13.TabIndex = 27;
            button13.Text = "正大";
            button13.UseVisualStyleBackColor = true;
            button13.Click += button13_Click;
            // 
            // button14
            // 
            button14.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button14.Location = new Point(-1, 658);
            button14.Name = "button14";
            button14.Size = new Size(75, 36);
            button14.TabIndex = 28;
            button14.Text = "正大";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button14_Click;
            // 
            // button15
            // 
            button15.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button15.Location = new Point(-1, 694);
            button15.Name = "button15";
            button15.Size = new Size(75, 36);
            button15.TabIndex = 29;
            button15.Text = "正大";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button15_Click;
            // 
            // button16
            // 
            button16.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button16.Location = new Point(480, 496);
            button16.Name = "button16";
            button16.Size = new Size(75, 36);
            button16.TabIndex = 30;
            button16.Text = "正大";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button16_Click;
            // 
            // button17
            // 
            button17.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button17.Location = new Point(480, 622);
            button17.Name = "button17";
            button17.Size = new Size(75, 36);
            button17.TabIndex = 31;
            button17.Text = "正大";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button17_Click;
            // 
            // button18
            // 
            button18.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button18.Location = new Point(480, 658);
            button18.Name = "button18";
            button18.Size = new Size(75, 36);
            button18.TabIndex = 32;
            button18.Text = "正大";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button18_Click;
            // 
            // button19
            // 
            button19.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button19.Location = new Point(961, 622);
            button19.Name = "button19";
            button19.Size = new Size(75, 36);
            button19.TabIndex = 33;
            button19.Text = "正大";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button19_Click;
            // 
            // button20
            // 
            button20.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button20.Location = new Point(961, 694);
            button20.Name = "button20";
            button20.Size = new Size(75, 36);
            button20.TabIndex = 34;
            button20.Text = "正大";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button21.Location = new Point(961, 658);
            button21.Name = "button21";
            button21.Size = new Size(75, 36);
            button21.TabIndex = 35;
            button21.Text = "正大";
            button21.UseVisualStyleBackColor = true;
            button21.Click += button21_Click;
            // 
            // button22
            // 
            button22.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button22.Location = new Point(1444, 622);
            button22.Name = "button22";
            button22.Size = new Size(75, 36);
            button22.TabIndex = 36;
            button22.Text = "正大";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button23.Location = new Point(1444, 658);
            button23.Name = "button23";
            button23.Size = new Size(75, 36);
            button23.TabIndex = 37;
            button23.Text = "正大";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // button24
            // 
            button24.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button24.Location = new Point(1444, 694);
            button24.Name = "button24";
            button24.Size = new Size(75, 36);
            button24.TabIndex = 38;
            button24.Text = "正大";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // buttonp
            // 
            buttonp.BackColor = Color.White;
            buttonp.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttonp.ForeColor = Color.Red;
            buttonp.Location = new Point(135, 0);
            buttonp.Name = "buttonp";
            buttonp.Size = new Size(150, 37);
            buttonp.TabIndex = 39;
            buttonp.Text = "详细信息";
            buttonp.UseVisualStyleBackColor = false;
            buttonp.Click += buttonp_Click;
            // 
            // buttongj
            // 
            buttongj.BackColor = Color.Green;
            buttongj.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttongj.ForeColor = Color.White;
            buttongj.Location = new Point(7, 0);
            buttongj.Name = "buttongj";
            buttongj.Size = new Size(122, 36);
            buttongj.TabIndex = 40;
            buttongj.Text = "关于软件";
            buttongj.UseVisualStyleBackColor = false;
            buttongj.Click += buttongj_Click;
            // 
            // buttonjin
            // 
            buttonjin.BackColor = Color.Black;
            buttonjin.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttonjin.ForeColor = Color.Gold;
            buttonjin.Location = new Point(291, -1);
            buttonjin.Name = "buttonjin";
            buttonjin.Size = new Size(106, 39);
            buttonjin.TabIndex = 43;
            buttonjin.Text = "9.99996";
            buttonjin.UseVisualStyleBackColor = false;
            buttonjin.Click += buttonjin_Click;
            // 
            // buttontu
            // 
            buttontu.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttontu.ForeColor = Color.Sienna;
            buttontu.Location = new Point(739, -1);
            buttontu.Name = "buttontu";
            buttontu.Size = new Size(106, 39);
            buttontu.TabIndex = 44;
            buttontu.Text = "9.99996";
            buttontu.UseVisualStyleBackColor = true;
            buttontu.Click += buttontu_Click;
            // 
            // buttonshui
            // 
            buttonshui.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttonshui.ForeColor = Color.DodgerBlue;
            buttonshui.Location = new Point(403, -1);
            buttonshui.Name = "buttonshui";
            buttonshui.Size = new Size(106, 39);
            buttonshui.TabIndex = 45;
            buttonshui.Text = "9.99996";
            buttonshui.UseVisualStyleBackColor = true;
            buttonshui.Click += buttonshui_Click;
            // 
            // buttonmu
            // 
            buttonmu.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttonmu.ForeColor = Color.Green;
            buttonmu.Location = new Point(515, -1);
            buttonmu.Name = "buttonmu";
            buttonmu.Size = new Size(106, 39);
            buttonmu.TabIndex = 46;
            buttonmu.Text = "9.99996";
            buttonmu.UseVisualStyleBackColor = true;
            buttonmu.Click += buttonmu_Click;
            // 
            // buttonhuo
            // 
            buttonhuo.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttonhuo.ForeColor = Color.Red;
            buttonhuo.Location = new Point(627, -1);
            buttonhuo.Name = "buttonhuo";
            buttonhuo.Size = new Size(106, 39);
            buttonhuo.TabIndex = 47;
            buttonhuo.Text = "9.99996";
            buttonhuo.UseVisualStyleBackColor = true;
            buttonhuo.Click += buttonhuo_Click;
            // 
            // buttongz
            // 
            buttongz.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            buttongz.Location = new Point(1557, 83);
            buttongz.Name = "buttongz";
            buttongz.Size = new Size(118, 39);
            buttongz.TabIndex = 48;
            buttongz.Text = "干支排盘";
            buttongz.UseVisualStyleBackColor = true;
            buttongz.Click += buttongz_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.BackColor = Color.DimGray;
            linkLabel1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel1.LinkColor = Color.Maroon;
            linkLabel1.Location = new Point(-2, 431);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(62, 31);
            linkLabel1.TabIndex = 50;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "内脏";
            // 
            // linkLabel2
            // 
            linkLabel2.AutoSize = true;
            linkLabel2.BackColor = Color.DimGray;
            linkLabel2.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel2.LinkColor = Color.Cyan;
            linkLabel2.Location = new Point(-2, 400);
            linkLabel2.Name = "linkLabel2";
            linkLabel2.Size = new Size(62, 31);
            linkLabel2.TabIndex = 51;
            linkLabel2.TabStop = true;
            linkLabel2.Text = "方位";
            // 
            // linkLabelntgss
            // 
            linkLabelntgss.AutoSize = true;
            linkLabelntgss.BackColor = Color.Black;
            linkLabelntgss.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelntgss.LinkColor = Color.Yellow;
            linkLabelntgss.Location = new Point(-2, 369);
            linkLabelntgss.Name = "linkLabelntgss";
            linkLabelntgss.Size = new Size(62, 31);
            linkLabelntgss.TabIndex = 52;
            linkLabelntgss.TabStop = true;
            linkLabelntgss.Text = "神煞";
            // 
            // linkLabel4
            // 
            linkLabel4.AutoSize = true;
            linkLabel4.BackColor = Color.White;
            linkLabel4.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel4.LinkColor = Color.BlueViolet;
            linkLabel4.Location = new Point(-2, 462);
            linkLabel4.Name = "linkLabel4";
            linkLabel4.Size = new Size(62, 31);
            linkLabel4.TabIndex = 53;
            linkLabel4.TabStop = true;
            linkLabel4.Text = "六亲";
            // 
            // linkLabel5
            // 
            linkLabel5.AutoSize = true;
            linkLabel5.BackColor = Color.White;
            linkLabel5.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel5.LinkColor = Color.Green;
            linkLabel5.Location = new Point(-2, 338);
            linkLabel5.Name = "linkLabel5";
            linkLabel5.Size = new Size(182, 31);
            linkLabel5.TabIndex = 54;
            linkLabel5.TabStop = true;
            linkLabel5.Text = "父亲和父系家族";
            // 
            // linkLabel6
            // 
            linkLabel6.AutoSize = true;
            linkLabel6.BackColor = Color.White;
            linkLabel6.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel6.LinkColor = Color.Black;
            linkLabel6.Location = new Point(-2, 307);
            linkLabel6.Name = "linkLabel6";
            linkLabel6.Size = new Size(78, 31);
            linkLabel6.TabIndex = 55;
            linkLabel6.TabStop = true;
            linkLabel6.Text = "1-9岁";
            // 
            // linkLabencs
            // 
            linkLabencs.AutoSize = true;
            linkLabencs.BackColor = Color.Black;
            linkLabencs.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabencs.ForeColor = Color.Black;
            linkLabencs.LinkColor = Color.White;
            linkLabencs.Location = new Point(-2, 276);
            linkLabencs.Name = "linkLabencs";
            linkLabencs.Size = new Size(62, 31);
            linkLabencs.TabIndex = 56;
            linkLabencs.TabStop = true;
            linkLabencs.Text = "长生";
            linkLabencs.LinkClicked += linkLabencs_LinkClicked;
            // 
            // linkLabel8
            // 
            linkLabel8.AutoSize = true;
            linkLabel8.BackColor = Color.White;
            linkLabel8.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel8.LinkColor = Color.BlueViolet;
            linkLabel8.Location = new Point(480, 462);
            linkLabel8.Name = "linkLabel8";
            linkLabel8.Size = new Size(62, 31);
            linkLabel8.TabIndex = 57;
            linkLabel8.TabStop = true;
            linkLabel8.Text = "六亲";
            // 
            // linkLabel9
            // 
            linkLabel9.AutoSize = true;
            linkLabel9.BackColor = Color.DimGray;
            linkLabel9.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel9.LinkColor = Color.Maroon;
            linkLabel9.Location = new Point(480, 431);
            linkLabel9.Name = "linkLabel9";
            linkLabel9.Size = new Size(62, 31);
            linkLabel9.TabIndex = 58;
            linkLabel9.TabStop = true;
            linkLabel9.Text = "内脏";
            // 
            // linkLabel10
            // 
            linkLabel10.AutoSize = true;
            linkLabel10.BackColor = Color.DimGray;
            linkLabel10.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel10.LinkColor = Color.Cyan;
            linkLabel10.Location = new Point(480, 400);
            linkLabel10.Name = "linkLabel10";
            linkLabel10.Size = new Size(62, 31);
            linkLabel10.TabIndex = 59;
            linkLabel10.TabStop = true;
            linkLabel10.Text = "方位";
            // 
            // linkLabelytgss
            // 
            linkLabelytgss.AutoSize = true;
            linkLabelytgss.BackColor = Color.Black;
            linkLabelytgss.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelytgss.LinkColor = Color.Yellow;
            linkLabelytgss.Location = new Point(480, 369);
            linkLabelytgss.Name = "linkLabelytgss";
            linkLabelytgss.Size = new Size(62, 31);
            linkLabelytgss.TabIndex = 60;
            linkLabelytgss.TabStop = true;
            linkLabelytgss.Text = "神煞";
            // 
            // linkLabel12
            // 
            linkLabel12.AutoSize = true;
            linkLabel12.BackColor = Color.White;
            linkLabel12.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel12.LinkColor = Color.Green;
            linkLabel12.Location = new Point(480, 338);
            linkLabel12.Name = "linkLabel12";
            linkLabel12.Size = new Size(326, 31);
            linkLabel12.TabIndex = 61;
            linkLabel12.TabStop = true;
            linkLabel12.Text = "父亲；哥；姐；包括社会上的";
            // 
            // linkLabel13
            // 
            linkLabel13.AutoSize = true;
            linkLabel13.BackColor = Color.White;
            linkLabel13.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel13.LinkColor = Color.Black;
            linkLabel13.Location = new Point(480, 307);
            linkLabel13.Name = "linkLabel13";
            linkLabel13.Size = new Size(108, 31);
            linkLabel13.TabIndex = 62;
            linkLabel13.TabStop = true;
            linkLabel13.Text = "19-27岁";
            // 
            // linkLabelycs
            // 
            linkLabelycs.AutoSize = true;
            linkLabelycs.BackColor = Color.Black;
            linkLabelycs.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelycs.ForeColor = Color.Black;
            linkLabelycs.LinkColor = Color.White;
            linkLabelycs.Location = new Point(480, 276);
            linkLabelycs.Name = "linkLabelycs";
            linkLabelycs.Size = new Size(62, 31);
            linkLabelycs.TabIndex = 63;
            linkLabelycs.TabStop = true;
            linkLabelycs.Text = "长生";
            linkLabelycs.LinkClicked += linkLabelycs_LinkClicked;
            // 
            // linkLabel15
            // 
            linkLabel15.AutoSize = true;
            linkLabel15.BackColor = Color.DimGray;
            linkLabel15.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel15.LinkColor = Color.Maroon;
            linkLabel15.Location = new Point(961, 431);
            linkLabel15.Name = "linkLabel15";
            linkLabel15.Size = new Size(62, 31);
            linkLabel15.TabIndex = 64;
            linkLabel15.TabStop = true;
            linkLabel15.Text = "内脏";
            // 
            // linkLabel17
            // 
            linkLabel17.AutoSize = true;
            linkLabel17.BackColor = Color.DimGray;
            linkLabel17.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel17.LinkColor = Color.Cyan;
            linkLabel17.Location = new Point(961, 400);
            linkLabel17.Name = "linkLabel17";
            linkLabel17.Size = new Size(62, 31);
            linkLabel17.TabIndex = 66;
            linkLabel17.TabStop = true;
            linkLabel17.Text = "方位";
            // 
            // linkLabelrtgss
            // 
            linkLabelrtgss.AutoSize = true;
            linkLabelrtgss.BackColor = Color.Black;
            linkLabelrtgss.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelrtgss.LinkColor = Color.Yellow;
            linkLabelrtgss.Location = new Point(961, 369);
            linkLabelrtgss.Name = "linkLabelrtgss";
            linkLabelrtgss.Size = new Size(62, 31);
            linkLabelrtgss.TabIndex = 67;
            linkLabelrtgss.TabStop = true;
            linkLabelrtgss.Text = "神煞";
            // 
            // linkLabel20
            // 
            linkLabel20.AutoSize = true;
            linkLabel20.BackColor = Color.DarkViolet;
            linkLabel20.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel20.LinkColor = Color.Yellow;
            linkLabel20.Location = new Point(961, 307);
            linkLabel20.Name = "linkLabel20";
            linkLabel20.Size = new Size(110, 31);
            linkLabel20.TabIndex = 69;
            linkLabel20.TabStop = true;
            linkLabel20.Text = "流年阴阳";
            // 
            // linkLabelrcs
            // 
            linkLabelrcs.AutoSize = true;
            linkLabelrcs.BackColor = Color.Black;
            linkLabelrcs.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelrcs.ForeColor = Color.Black;
            linkLabelrcs.LinkColor = Color.White;
            linkLabelrcs.Location = new Point(961, 276);
            linkLabelrcs.Name = "linkLabelrcs";
            linkLabelrcs.Size = new Size(62, 31);
            linkLabelrcs.TabIndex = 70;
            linkLabelrcs.TabStop = true;
            linkLabelrcs.Text = "长生";
            linkLabelrcs.LinkClicked += linkLabelrcs_LinkClicked;
            // 
            // linkLabel22
            // 
            linkLabel22.AutoSize = true;
            linkLabel22.BackColor = Color.White;
            linkLabel22.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel22.LinkColor = Color.BlueViolet;
            linkLabel22.Location = new Point(1444, 462);
            linkLabel22.Name = "linkLabel22";
            linkLabel22.Size = new Size(62, 31);
            linkLabel22.TabIndex = 71;
            linkLabel22.TabStop = true;
            linkLabel22.Text = "六亲";
            linkLabel22.LinkClicked += linkLabel22_LinkClicked;
            // 
            // linkLabel23
            // 
            linkLabel23.AutoSize = true;
            linkLabel23.BackColor = Color.DimGray;
            linkLabel23.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel23.LinkColor = Color.Maroon;
            linkLabel23.Location = new Point(1444, 431);
            linkLabel23.Name = "linkLabel23";
            linkLabel23.Size = new Size(62, 31);
            linkLabel23.TabIndex = 72;
            linkLabel23.TabStop = true;
            linkLabel23.Text = "内脏";
            linkLabel23.LinkClicked += linkLabel23_LinkClicked;
            // 
            // linkLabel24
            // 
            linkLabel24.AutoSize = true;
            linkLabel24.BackColor = Color.DimGray;
            linkLabel24.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel24.LinkColor = Color.Cyan;
            linkLabel24.Location = new Point(1444, 400);
            linkLabel24.Name = "linkLabel24";
            linkLabel24.Size = new Size(62, 31);
            linkLabel24.TabIndex = 73;
            linkLabel24.TabStop = true;
            linkLabel24.Text = "方位";
            linkLabel24.LinkClicked += linkLabel24_LinkClicked;
            // 
            // linkLabelstgss
            // 
            linkLabelstgss.AutoSize = true;
            linkLabelstgss.BackColor = Color.Black;
            linkLabelstgss.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelstgss.LinkColor = Color.Yellow;
            linkLabelstgss.Location = new Point(1444, 369);
            linkLabelstgss.Name = "linkLabelstgss";
            linkLabelstgss.Size = new Size(62, 31);
            linkLabelstgss.TabIndex = 74;
            linkLabelstgss.TabStop = true;
            linkLabelstgss.Text = "神煞";
            linkLabelstgss.LinkClicked += linkLabelsgp_LinkClicked;
            // 
            // linkLabel26
            // 
            linkLabel26.AutoSize = true;
            linkLabel26.BackColor = Color.White;
            linkLabel26.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel26.LinkColor = Color.Green;
            linkLabel26.Location = new Point(1444, 338);
            linkLabel26.Name = "linkLabel26";
            linkLabel26.Size = new Size(62, 31);
            linkLabel26.TabIndex = 75;
            linkLabel26.TabStop = true;
            linkLabel26.Text = "长子";
            linkLabel26.LinkClicked += linkLabel26_LinkClicked;
            // 
            // linkLabel27
            // 
            linkLabel27.AutoSize = true;
            linkLabel27.BackColor = Color.White;
            linkLabel27.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel27.LinkColor = Color.Black;
            linkLabel27.Location = new Point(1444, 307);
            linkLabel27.Name = "linkLabel27";
            linkLabel27.Size = new Size(108, 31);
            linkLabel27.TabIndex = 76;
            linkLabel27.TabStop = true;
            linkLabel27.Text = "46-54岁";
            linkLabel27.LinkClicked += linkLabel27_LinkClicked;
            // 
            // linkLabelscs
            // 
            linkLabelscs.AutoSize = true;
            linkLabelscs.BackColor = Color.Black;
            linkLabelscs.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelscs.ForeColor = Color.Black;
            linkLabelscs.LinkColor = Color.White;
            linkLabelscs.Location = new Point(1444, 276);
            linkLabelscs.Name = "linkLabelscs";
            linkLabelscs.Size = new Size(62, 31);
            linkLabelscs.TabIndex = 77;
            linkLabelscs.TabStop = true;
            linkLabelscs.Text = "长生";
            linkLabelscs.LinkClicked += linkLabelscs_LinkClicked;
            // 
            // linkLabel29
            // 
            linkLabel29.AutoSize = true;
            linkLabel29.BackColor = Color.White;
            linkLabel29.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel29.LinkColor = Color.BlueViolet;
            linkLabel29.Location = new Point(-6, 765);
            linkLabel29.Name = "linkLabel29";
            linkLabel29.Size = new Size(62, 31);
            linkLabel29.TabIndex = 78;
            linkLabel29.TabStop = true;
            linkLabel29.Text = "六亲";
            // 
            // linkLabel30
            // 
            linkLabel30.AutoSize = true;
            linkLabel30.BackColor = Color.White;
            linkLabel30.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel30.LinkColor = Color.BlueViolet;
            linkLabel30.Location = new Point(-6, 796);
            linkLabel30.Name = "linkLabel30";
            linkLabel30.Size = new Size(62, 31);
            linkLabel30.TabIndex = 79;
            linkLabel30.TabStop = true;
            linkLabel30.Text = "六亲";
            // 
            // linkLabel31
            // 
            linkLabel31.AutoSize = true;
            linkLabel31.BackColor = Color.White;
            linkLabel31.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel31.LinkColor = Color.BlueViolet;
            linkLabel31.Location = new Point(-6, 733);
            linkLabel31.Name = "linkLabel31";
            linkLabel31.Size = new Size(62, 31);
            linkLabel31.TabIndex = 80;
            linkLabel31.TabStop = true;
            linkLabel31.Text = "六亲";
            // 
            // linkLabel32
            // 
            linkLabel32.AutoSize = true;
            linkLabel32.BackColor = Color.DimGray;
            linkLabel32.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel32.LinkColor = Color.Maroon;
            linkLabel32.Location = new Point(-6, 827);
            linkLabel32.Name = "linkLabel32";
            linkLabel32.Size = new Size(62, 31);
            linkLabel32.TabIndex = 81;
            linkLabel32.TabStop = true;
            linkLabel32.Text = "内脏";
            // 
            // linkLabel33
            // 
            linkLabel33.AutoSize = true;
            linkLabel33.BackColor = Color.DimGray;
            linkLabel33.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel33.LinkColor = Color.Cyan;
            linkLabel33.Location = new Point(-6, 858);
            linkLabel33.Name = "linkLabel33";
            linkLabel33.Size = new Size(62, 31);
            linkLabel33.TabIndex = 82;
            linkLabel33.TabStop = true;
            linkLabel33.Text = "方位";
            // 
            // linkLabelndzss1
            // 
            linkLabelndzss1.AutoSize = true;
            linkLabelndzss1.BackColor = Color.Black;
            linkLabelndzss1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelndzss1.LinkColor = Color.Yellow;
            linkLabelndzss1.Location = new Point(-6, 889);
            linkLabelndzss1.Name = "linkLabelndzss1";
            linkLabelndzss1.Size = new Size(62, 31);
            linkLabelndzss1.TabIndex = 83;
            linkLabelndzss1.TabStop = true;
            linkLabelndzss1.Text = "神煞";
            // 
            // linkLabel35
            // 
            linkLabel35.AutoSize = true;
            linkLabel35.BackColor = Color.White;
            linkLabel35.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel35.LinkColor = Color.Green;
            linkLabel35.Location = new Point(-6, 951);
            linkLabel35.Name = "linkLabel35";
            linkLabel35.Size = new Size(182, 31);
            linkLabel35.TabIndex = 84;
            linkLabel35.TabStop = true;
            linkLabel35.Text = "母亲和母系家族";
            // 
            // linkLabel36
            // 
            linkLabel36.AutoSize = true;
            linkLabel36.BackColor = Color.White;
            linkLabel36.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel36.LinkColor = Color.Black;
            linkLabel36.Location = new Point(-6, 982);
            linkLabel36.Name = "linkLabel36";
            linkLabel36.Size = new Size(108, 31);
            linkLabel36.TabIndex = 85;
            linkLabel36.TabStop = true;
            linkLabel36.Text = "10-18岁";
            // 
            // linkLabel37
            // 
            linkLabel37.AutoSize = true;
            linkLabel37.BackColor = Color.White;
            linkLabel37.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel37.LinkColor = Color.Black;
            linkLabel37.Location = new Point(477, 982);
            linkLabel37.Name = "linkLabel37";
            linkLabel37.Size = new Size(108, 31);
            linkLabel37.TabIndex = 86;
            linkLabel37.TabStop = true;
            linkLabel37.Text = "28-36岁";
            // 
            // linkLabel38
            // 
            linkLabel38.AutoSize = true;
            linkLabel38.BackColor = Color.White;
            linkLabel38.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel38.LinkColor = Color.Green;
            linkLabel38.Location = new Point(477, 951);
            linkLabel38.Name = "linkLabel38";
            linkLabel38.Size = new Size(326, 31);
            linkLabel38.TabIndex = 87;
            linkLabel38.TabStop = true;
            linkLabel38.Text = "母亲；弟；妹；包括社会上的";
            // 
            // linkLabelydzss1
            // 
            linkLabelydzss1.AutoSize = true;
            linkLabelydzss1.BackColor = Color.Black;
            linkLabelydzss1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelydzss1.LinkColor = Color.Yellow;
            linkLabelydzss1.Location = new Point(477, 889);
            linkLabelydzss1.Name = "linkLabelydzss1";
            linkLabelydzss1.Size = new Size(62, 31);
            linkLabelydzss1.TabIndex = 88;
            linkLabelydzss1.TabStop = true;
            linkLabelydzss1.Text = "神煞";
            // 
            // linkLabel40
            // 
            linkLabel40.AutoSize = true;
            linkLabel40.BackColor = Color.DimGray;
            linkLabel40.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel40.LinkColor = Color.Cyan;
            linkLabel40.Location = new Point(477, 858);
            linkLabel40.Name = "linkLabel40";
            linkLabel40.Size = new Size(62, 31);
            linkLabel40.TabIndex = 89;
            linkLabel40.TabStop = true;
            linkLabel40.Text = "方位";
            // 
            // linkLabel41
            // 
            linkLabel41.AutoSize = true;
            linkLabel41.BackColor = Color.DimGray;
            linkLabel41.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel41.LinkColor = Color.Maroon;
            linkLabel41.Location = new Point(477, 827);
            linkLabel41.Name = "linkLabel41";
            linkLabel41.Size = new Size(62, 31);
            linkLabel41.TabIndex = 90;
            linkLabel41.TabStop = true;
            linkLabel41.Text = "内脏";
            // 
            // linkLabel42
            // 
            linkLabel42.AutoSize = true;
            linkLabel42.BackColor = Color.White;
            linkLabel42.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel42.LinkColor = Color.BlueViolet;
            linkLabel42.Location = new Point(477, 796);
            linkLabel42.Name = "linkLabel42";
            linkLabel42.Size = new Size(62, 31);
            linkLabel42.TabIndex = 91;
            linkLabel42.TabStop = true;
            linkLabel42.Text = "六亲";
            // 
            // linkLabel43
            // 
            linkLabel43.AutoSize = true;
            linkLabel43.BackColor = Color.White;
            linkLabel43.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel43.LinkColor = Color.BlueViolet;
            linkLabel43.Location = new Point(477, 765);
            linkLabel43.Name = "linkLabel43";
            linkLabel43.Size = new Size(62, 31);
            linkLabel43.TabIndex = 92;
            linkLabel43.TabStop = true;
            linkLabel43.Text = "六亲";
            // 
            // linkLabel44
            // 
            linkLabel44.AutoSize = true;
            linkLabel44.BackColor = Color.White;
            linkLabel44.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel44.LinkColor = Color.BlueViolet;
            linkLabel44.Location = new Point(477, 733);
            linkLabel44.Name = "linkLabel44";
            linkLabel44.Size = new Size(62, 31);
            linkLabel44.TabIndex = 93;
            linkLabel44.TabStop = true;
            linkLabel44.Text = "六亲";
            // 
            // linkLabel45
            // 
            linkLabel45.AutoSize = true;
            linkLabel45.BackColor = Color.White;
            linkLabel45.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel45.LinkColor = Color.Black;
            linkLabel45.Location = new Point(956, 982);
            linkLabel45.Name = "linkLabel45";
            linkLabel45.Size = new Size(108, 31);
            linkLabel45.TabIndex = 94;
            linkLabel45.TabStop = true;
            linkLabel45.Text = "37-45岁";
            // 
            // linkLabel46
            // 
            linkLabel46.AutoSize = true;
            linkLabel46.BackColor = Color.White;
            linkLabel46.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel46.LinkColor = Color.Green;
            linkLabel46.Location = new Point(956, 951);
            linkLabel46.Name = "linkLabel46";
            linkLabel46.Size = new Size(206, 31);
            linkLabel46.TabIndex = 95;
            linkLabel46.TabStop = true;
            linkLabel46.Text = "配偶和配偶的家族";
            // 
            // linkLabelrdzss1
            // 
            linkLabelrdzss1.AutoSize = true;
            linkLabelrdzss1.BackColor = Color.Black;
            linkLabelrdzss1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelrdzss1.LinkColor = Color.Yellow;
            linkLabelrdzss1.Location = new Point(956, 889);
            linkLabelrdzss1.Name = "linkLabelrdzss1";
            linkLabelrdzss1.Size = new Size(62, 31);
            linkLabelrdzss1.TabIndex = 96;
            linkLabelrdzss1.TabStop = true;
            linkLabelrdzss1.Text = "神煞";
            // 
            // linkLabel48
            // 
            linkLabel48.AutoSize = true;
            linkLabel48.BackColor = Color.DimGray;
            linkLabel48.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel48.LinkColor = Color.Cyan;
            linkLabel48.Location = new Point(956, 858);
            linkLabel48.Name = "linkLabel48";
            linkLabel48.Size = new Size(62, 31);
            linkLabel48.TabIndex = 97;
            linkLabel48.TabStop = true;
            linkLabel48.Text = "方位";
            // 
            // linkLabel49
            // 
            linkLabel49.AutoSize = true;
            linkLabel49.BackColor = Color.DimGray;
            linkLabel49.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel49.LinkColor = Color.Maroon;
            linkLabel49.Location = new Point(956, 827);
            linkLabel49.Name = "linkLabel49";
            linkLabel49.Size = new Size(62, 31);
            linkLabel49.TabIndex = 98;
            linkLabel49.TabStop = true;
            linkLabel49.Text = "内脏";
            // 
            // linkLabel50
            // 
            linkLabel50.AutoSize = true;
            linkLabel50.BackColor = Color.White;
            linkLabel50.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel50.LinkColor = Color.BlueViolet;
            linkLabel50.Location = new Point(956, 796);
            linkLabel50.Name = "linkLabel50";
            linkLabel50.Size = new Size(62, 31);
            linkLabel50.TabIndex = 99;
            linkLabel50.TabStop = true;
            linkLabel50.Text = "六亲";
            // 
            // linkLabel51
            // 
            linkLabel51.AutoSize = true;
            linkLabel51.BackColor = Color.White;
            linkLabel51.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel51.LinkColor = Color.BlueViolet;
            linkLabel51.Location = new Point(956, 765);
            linkLabel51.Name = "linkLabel51";
            linkLabel51.Size = new Size(62, 31);
            linkLabel51.TabIndex = 100;
            linkLabel51.TabStop = true;
            linkLabel51.Text = "六亲";
            // 
            // linkLabel52
            // 
            linkLabel52.AutoSize = true;
            linkLabel52.BackColor = Color.White;
            linkLabel52.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel52.LinkColor = Color.BlueViolet;
            linkLabel52.Location = new Point(956, 733);
            linkLabel52.Name = "linkLabel52";
            linkLabel52.Size = new Size(62, 31);
            linkLabel52.TabIndex = 101;
            linkLabel52.TabStop = true;
            linkLabel52.Text = "六亲";
            // 
            // linkLabel53
            // 
            linkLabel53.AutoSize = true;
            linkLabel53.BackColor = Color.White;
            linkLabel53.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel53.LinkColor = Color.BlueViolet;
            linkLabel53.Location = new Point(1439, 765);
            linkLabel53.Name = "linkLabel53";
            linkLabel53.Size = new Size(62, 31);
            linkLabel53.TabIndex = 102;
            linkLabel53.TabStop = true;
            linkLabel53.Text = "六亲";
            // 
            // linkLabel54
            // 
            linkLabel54.AutoSize = true;
            linkLabel54.BackColor = Color.White;
            linkLabel54.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel54.LinkColor = Color.BlueViolet;
            linkLabel54.Location = new Point(1439, 796);
            linkLabel54.Name = "linkLabel54";
            linkLabel54.Size = new Size(62, 31);
            linkLabel54.TabIndex = 103;
            linkLabel54.TabStop = true;
            linkLabel54.Text = "六亲";
            // 
            // linkLabel55
            // 
            linkLabel55.AutoSize = true;
            linkLabel55.BackColor = Color.DimGray;
            linkLabel55.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel55.LinkColor = Color.Maroon;
            linkLabel55.Location = new Point(1439, 827);
            linkLabel55.Name = "linkLabel55";
            linkLabel55.Size = new Size(62, 31);
            linkLabel55.TabIndex = 104;
            linkLabel55.TabStop = true;
            linkLabel55.Text = "内脏";
            // 
            // linkLabel56
            // 
            linkLabel56.AutoSize = true;
            linkLabel56.BackColor = Color.DimGray;
            linkLabel56.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel56.LinkColor = Color.Cyan;
            linkLabel56.Location = new Point(1439, 858);
            linkLabel56.Name = "linkLabel56";
            linkLabel56.Size = new Size(62, 31);
            linkLabel56.TabIndex = 105;
            linkLabel56.TabStop = true;
            linkLabel56.Text = "方位";
            // 
            // linkLabelsdzss1
            // 
            linkLabelsdzss1.AutoSize = true;
            linkLabelsdzss1.BackColor = Color.Black;
            linkLabelsdzss1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelsdzss1.LinkColor = Color.Yellow;
            linkLabelsdzss1.Location = new Point(1439, 889);
            linkLabelsdzss1.Name = "linkLabelsdzss1";
            linkLabelsdzss1.Size = new Size(62, 31);
            linkLabelsdzss1.TabIndex = 106;
            linkLabelsdzss1.TabStop = true;
            linkLabelsdzss1.Text = "神煞";
            // 
            // linkLabel58
            // 
            linkLabel58.AutoSize = true;
            linkLabel58.BackColor = Color.White;
            linkLabel58.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel58.LinkColor = Color.Green;
            linkLabel58.Location = new Point(1439, 951);
            linkLabel58.Name = "linkLabel58";
            linkLabel58.Size = new Size(62, 31);
            linkLabel58.TabIndex = 107;
            linkLabel58.TabStop = true;
            linkLabel58.Text = "次子";
            // 
            // linkLabel59
            // 
            linkLabel59.AutoSize = true;
            linkLabel59.BackColor = Color.White;
            linkLabel59.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel59.LinkColor = Color.BlueViolet;
            linkLabel59.Location = new Point(1439, 733);
            linkLabel59.Name = "linkLabel59";
            linkLabel59.Size = new Size(62, 31);
            linkLabel59.TabIndex = 108;
            linkLabel59.TabStop = true;
            linkLabel59.Text = "六亲";
            // 
            // linkLabel60
            // 
            linkLabel60.AutoSize = true;
            linkLabel60.BackColor = Color.White;
            linkLabel60.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel60.LinkColor = Color.Black;
            linkLabel60.Location = new Point(1439, 982);
            linkLabel60.Name = "linkLabel60";
            linkLabel60.Size = new Size(116, 31);
            linkLabel60.TabIndex = 109;
            linkLabel60.TabStop = true;
            linkLabel60.Text = "55岁以后";
            // 
            // richTextBox1
            // 
            richTextBox1.BackColor = Color.DimGray;
            richTextBox1.Font = new Font("微软雅黑", 21.75F, FontStyle.Bold);
            richTextBox1.ForeColor = Color.GreenYellow;
            richTextBox1.Location = new Point(3, 39);
            richTextBox1.Name = "richTextBox1";
            richTextBox1.Size = new Size(1545, 191);
            richTextBox1.TabIndex = 122;
            richTextBox1.Text = "";
            // 
            // linkLabel7hff
            // 
            linkLabel7hff.AutoSize = true;
            linkLabel7hff.BackColor = Color.White;
            linkLabel7hff.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel7hff.LinkColor = Color.Green;
            linkLabel7hff.Location = new Point(961, 462);
            linkLabel7hff.Name = "linkLabel7hff";
            linkLabel7hff.Size = new Size(110, 31);
            linkLabel7hff.TabIndex = 128;
            linkLabel7hff.TabStop = true;
            linkLabel7hff.Text = "主盘强弱";
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            label1.ForeColor = Color.Black;
            label1.Location = new Point(1785, 4);
            label1.Margin = new Padding(0);
            label1.Name = "label1";
            label1.Size = new Size(118, 31);
            label1.TabIndex = 130;
            label1.Text = "99:99:99";
            // 
            // button10
            // 
            button10.BackColor = Color.White;
            button10.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button10.Location = new Point(-2, 235);
            button10.Name = "button10";
            button10.Size = new Size(95, 38);
            button10.TabIndex = 131;
            button10.Text = "纳音全";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button10_Click;
            // 
            // button11
            // 
            button11.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button11.Location = new Point(480, 235);
            button11.Name = "button11";
            button11.Size = new Size(95, 38);
            button11.TabIndex = 132;
            button11.Text = "纳音全";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click;
            // 
            // button12
            // 
            button12.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button12.Location = new Point(961, 235);
            button12.Name = "button12";
            button12.Size = new Size(95, 38);
            button12.TabIndex = 133;
            button12.Text = "纳音全";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button12_Click;
            // 
            // button25
            // 
            button25.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button25.Location = new Point(1444, 235);
            button25.Name = "button25";
            button25.Size = new Size(95, 38);
            button25.TabIndex = 134;
            button25.Text = "纳音全";
            button25.UseVisualStyleBackColor = true;
            button25.Click += button25_Click;
            // 
            // button26
            // 
            button26.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button26.Location = new Point(1581, 579);
            button26.Name = "button26";
            button26.Size = new Size(36, 36);
            button26.TabIndex = 142;
            button26.Text = "正";
            button26.UseVisualStyleBackColor = true;
            button26.Visible = false;
            // 
            // button27
            // 
            button27.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button27.Location = new Point(1100, 581);
            button27.Name = "button27";
            button27.Size = new Size(36, 36);
            button27.TabIndex = 141;
            button27.Text = "正";
            button27.UseVisualStyleBackColor = true;
            button27.Visible = false;
            // 
            // button28
            // 
            button28.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button28.Location = new Point(623, 579);
            button28.Name = "button28";
            button28.Size = new Size(36, 36);
            button28.TabIndex = 140;
            button28.Text = "正";
            button28.UseVisualStyleBackColor = true;
            button28.Visible = false;
            // 
            // button29
            // 
            button29.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button29.Location = new Point(139, 581);
            button29.Name = "button29";
            button29.Size = new Size(36, 36);
            button29.TabIndex = 139;
            button29.Text = "正";
            button29.UseVisualStyleBackColor = true;
            button29.Visible = false;
            // 
            // button30
            // 
            button30.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button30.Location = new Point(1100, 617);
            button30.Name = "button30";
            button30.Size = new Size(36, 36);
            button30.TabIndex = 138;
            button30.Text = "正";
            button30.UseVisualStyleBackColor = true;
            button30.Visible = false;
            // 
            // button31
            // 
            button31.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button31.Location = new Point(1581, 615);
            button31.Name = "button31";
            button31.Size = new Size(36, 36);
            button31.TabIndex = 137;
            button31.Text = "正";
            button31.UseVisualStyleBackColor = true;
            button31.Visible = false;
            // 
            // button32
            // 
            button32.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button32.Location = new Point(623, 615);
            button32.Name = "button32";
            button32.Size = new Size(36, 36);
            button32.TabIndex = 136;
            button32.Text = "正";
            button32.UseVisualStyleBackColor = true;
            button32.Visible = false;
            // 
            // button33
            // 
            button33.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button33.Location = new Point(139, 617);
            button33.Name = "button33";
            button33.Size = new Size(36, 36);
            button33.TabIndex = 135;
            button33.Text = "正";
            button33.UseVisualStyleBackColor = true;
            button33.Visible = false;
            // 
            // button34
            // 
            button34.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            button34.Location = new Point(1556, 496);
            button34.Name = "button34";
            button34.Size = new Size(87, 36);
            button34.TabIndex = 146;
            button34.Text = "纳音全";
            button34.UseVisualStyleBackColor = true;
            button34.Visible = false;
            // 
            // button35
            // 
            button35.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            button35.Location = new Point(1075, 498);
            button35.Name = "button35";
            button35.Size = new Size(87, 36);
            button35.TabIndex = 145;
            button35.Text = "纳音全";
            button35.UseVisualStyleBackColor = true;
            button35.Visible = false;
            button35.Click += button35_Click;
            // 
            // button36
            // 
            button36.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            button36.Location = new Point(598, 496);
            button36.Name = "button36";
            button36.Size = new Size(87, 36);
            button36.TabIndex = 144;
            button36.Text = "纳音全";
            button36.UseVisualStyleBackColor = true;
            button36.Visible = false;
            // 
            // button37
            // 
            button37.BackColor = Color.White;
            button37.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            button37.Location = new Point(114, 498);
            button37.Name = "button37";
            button37.Size = new Size(87, 36);
            button37.TabIndex = 143;
            button37.Text = "纳音全";
            button37.UseVisualStyleBackColor = false;
            button37.Visible = false;
            // 
            // button52
            // 
            button52.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button52.Location = new Point(1562, 655);
            button52.Name = "button52";
            button52.Size = new Size(75, 36);
            button52.TabIndex = 172;
            button52.Text = "正大";
            button52.UseVisualStyleBackColor = true;
            // 
            // button55
            // 
            button55.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button55.Location = new Point(1081, 657);
            button55.Name = "button55";
            button55.Size = new Size(75, 36);
            button55.TabIndex = 169;
            button55.Text = "正大";
            button55.UseVisualStyleBackColor = true;
            // 
            // button57
            // 
            button57.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button57.Location = new Point(604, 655);
            button57.Name = "button57";
            button57.Size = new Size(75, 36);
            button57.TabIndex = 167;
            button57.Text = "正大";
            button57.UseVisualStyleBackColor = true;
            // 
            // button58
            // 
            button58.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button58.Location = new Point(604, 537);
            button58.Name = "button58";
            button58.Size = new Size(75, 36);
            button58.TabIndex = 166;
            button58.Text = "正大";
            button58.UseVisualStyleBackColor = true;
            button58.Click += button58_Click;
            // 
            // button61
            // 
            button61.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button61.Location = new Point(120, 657);
            button61.Name = "button61";
            button61.Size = new Size(75, 36);
            button61.TabIndex = 163;
            button61.Text = "正大";
            button61.UseVisualStyleBackColor = true;
            // 
            // button62
            // 
            button62.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button62.Location = new Point(1562, 537);
            button62.Name = "button62";
            button62.Size = new Size(75, 36);
            button62.TabIndex = 162;
            button62.Text = "正大";
            button62.UseVisualStyleBackColor = true;
            // 
            // button63
            // 
            button63.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button63.Location = new Point(1081, 539);
            button63.Name = "button63";
            button63.Size = new Size(75, 36);
            button63.TabIndex = 161;
            button63.Text = "旺衰";
            button63.UseVisualStyleBackColor = true;
            // 
            // button65
            // 
            button65.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button65.Location = new Point(120, 539);
            button65.Name = "button65";
            button65.Size = new Size(75, 36);
            button65.TabIndex = 159;
            button65.Text = "正大";
            button65.UseVisualStyleBackColor = true;
            // 
            // button54
            // 
            button54.Location = new Point(1298, 827);
            button54.Name = "button54";
            button54.Size = new Size(40, 32);
            button54.TabIndex = 189;
            button54.Text = "关";
            button54.UseVisualStyleBackColor = true;
            button54.Visible = false;
            button54.Click += button54_Click;
            // 
            // button56
            // 
            button56.Location = new Point(1252, 827);
            button56.Name = "button56";
            button56.Size = new Size(40, 32);
            button56.TabIndex = 192;
            button56.Text = "开";
            button56.UseVisualStyleBackColor = true;
            button56.Visible = false;
            button56.Click += button56_Click;
            // 
            // linkLabel25
            // 
            linkLabel25.AutoSize = true;
            linkLabel25.BackColor = Color.DarkViolet;
            linkLabel25.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel25.LinkColor = Color.Yellow;
            linkLabel25.Location = new Point(961, 338);
            linkLabel25.Name = "linkLabel25";
            linkLabel25.Size = new Size(62, 31);
            linkLabel25.TabIndex = 195;
            linkLabel25.TabStop = true;
            linkLabel25.Text = "阴阳";
            // 
            // button59
            // 
            button59.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            button59.Location = new Point(1388, 0);
            button59.Name = "button59";
            button59.Size = new Size(118, 38);
            button59.TabIndex = 196;
            button59.Text = "时间排盘";
            button59.UseVisualStyleBackColor = true;
            button59.Click += button59_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.BackColor = Color.Sienna;
            checkBox1.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            checkBox1.ForeColor = Color.White;
            checkBox1.Location = new Point(1301, 2);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(81, 35);
            checkBox1.TabIndex = 197;
            checkBox1.Text = "农历";
            checkBox1.UseVisualStyleBackColor = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // numericUpDownyear
            // 
            numericUpDownyear.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            numericUpDownyear.Location = new Point(1512, 2);
            numericUpDownyear.Maximum = new decimal(new int[] { 9999, 0, 0, 0 });
            numericUpDownyear.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownyear.Name = "numericUpDownyear";
            numericUpDownyear.Size = new Size(81, 35);
            numericUpDownyear.TabIndex = 198;
            numericUpDownyear.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownyear.ValueChanged += numericUpDownyear_ValueChanged;
            numericUpDownyear.Click += button59_Click;
            // 
            // numericUpDownmonth
            // 
            numericUpDownmonth.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            numericUpDownmonth.Location = new Point(1599, 2);
            numericUpDownmonth.Maximum = new decimal(new int[] { 12, 0, 0, 0 });
            numericUpDownmonth.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownmonth.Name = "numericUpDownmonth";
            numericUpDownmonth.Size = new Size(57, 35);
            numericUpDownmonth.TabIndex = 199;
            numericUpDownmonth.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownmonth.ValueChanged += numericUpDownmonth_ValueChanged;
            numericUpDownmonth.Click += button59_Click;
            // 
            // numericUpDownday
            // 
            numericUpDownday.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            numericUpDownday.Location = new Point(1662, 2);
            numericUpDownday.Maximum = new decimal(new int[] { 31, 0, 0, 0 });
            numericUpDownday.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownday.Name = "numericUpDownday";
            numericUpDownday.Size = new Size(57, 35);
            numericUpDownday.TabIndex = 200;
            numericUpDownday.Value = new decimal(new int[] { 1, 0, 0, 0 });
            numericUpDownday.ValueChanged += numericUpDownday_ValueChanged;
            numericUpDownday.Click += button59_Click;
            // 
            // numericUpDownhour
            // 
            numericUpDownhour.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            numericUpDownhour.Location = new Point(1725, 2);
            numericUpDownhour.Maximum = new decimal(new int[] { 23, 0, 0, 0 });
            numericUpDownhour.Name = "numericUpDownhour";
            numericUpDownhour.Size = new Size(57, 35);
            numericUpDownhour.TabIndex = 201;
            numericUpDownhour.Click += button59_Click;
            // 
            // linkLabel28
            // 
            linkLabel28.AutoSize = true;
            linkLabel28.BackColor = Color.White;
            linkLabel28.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabel28.LinkColor = Color.Black;
            linkLabel28.Location = new Point(1557, 125);
            linkLabel28.Name = "linkLabel28";
            linkLabel28.Size = new Size(62, 31);
            linkLabel28.TabIndex = 202;
            linkLabel28.TabStop = true;
            linkLabel28.Text = "日期";
            // 
            // checkBoxln
            // 
            checkBoxln.AutoSize = true;
            checkBoxln.BackColor = Color.White;
            checkBoxln.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            checkBoxln.ForeColor = Color.Black;
            checkBoxln.Location = new Point(1066, 2);
            checkBoxln.Name = "checkBoxln";
            checkBoxln.Size = new Size(105, 35);
            checkBoxln.TabIndex = 203;
            checkBoxln.Text = "排流年";
            checkBoxln.UseVisualStyleBackColor = false;
            // 
            // linkLabelsdzss2
            // 
            linkLabelsdzss2.AutoSize = true;
            linkLabelsdzss2.BackColor = Color.Black;
            linkLabelsdzss2.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelsdzss2.LinkColor = Color.Yellow;
            linkLabelsdzss2.Location = new Point(1439, 920);
            linkLabelsdzss2.Name = "linkLabelsdzss2";
            linkLabelsdzss2.Size = new Size(62, 31);
            linkLabelsdzss2.TabIndex = 207;
            linkLabelsdzss2.TabStop = true;
            linkLabelsdzss2.Text = "神煞";
            // 
            // linkLabelrdzss2
            // 
            linkLabelrdzss2.AutoSize = true;
            linkLabelrdzss2.BackColor = Color.Black;
            linkLabelrdzss2.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelrdzss2.LinkColor = Color.Yellow;
            linkLabelrdzss2.Location = new Point(956, 920);
            linkLabelrdzss2.Name = "linkLabelrdzss2";
            linkLabelrdzss2.Size = new Size(62, 31);
            linkLabelrdzss2.TabIndex = 206;
            linkLabelrdzss2.TabStop = true;
            linkLabelrdzss2.Text = "神煞";
            // 
            // linkLabelydzss2
            // 
            linkLabelydzss2.AutoSize = true;
            linkLabelydzss2.BackColor = Color.Black;
            linkLabelydzss2.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelydzss2.LinkColor = Color.Yellow;
            linkLabelydzss2.Location = new Point(477, 920);
            linkLabelydzss2.Name = "linkLabelydzss2";
            linkLabelydzss2.Size = new Size(62, 31);
            linkLabelydzss2.TabIndex = 205;
            linkLabelydzss2.TabStop = true;
            linkLabelydzss2.Text = "神煞";
            // 
            // linkLabelndzss2
            // 
            linkLabelndzss2.AutoSize = true;
            linkLabelndzss2.BackColor = Color.Black;
            linkLabelndzss2.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabelndzss2.LinkColor = Color.Yellow;
            linkLabelndzss2.Location = new Point(-6, 920);
            linkLabelndzss2.Name = "linkLabelndzss2";
            linkLabelndzss2.Size = new Size(62, 31);
            linkLabelndzss2.TabIndex = 204;
            linkLabelndzss2.TabStop = true;
            linkLabelndzss2.Text = "神煞";
            // 
            // linkLabellnsss
            // 
            linkLabellnsss.AutoSize = true;
            linkLabellnsss.BackColor = Color.Black;
            linkLabellnsss.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabellnsss.LinkColor = Color.Yellow;
            linkLabellnsss.Location = new Point(1562, 696);
            linkLabellnsss.Name = "linkLabellnsss";
            linkLabellnsss.Size = new Size(62, 31);
            linkLabellnsss.TabIndex = 211;
            linkLabellnsss.TabStop = true;
            linkLabellnsss.Text = "神煞";
            linkLabellnsss.Visible = false;
            // 
            // linkLabellnssr
            // 
            linkLabellnssr.AutoSize = true;
            linkLabellnssr.BackColor = Color.Black;
            linkLabellnssr.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabellnssr.LinkColor = Color.Yellow;
            linkLabellnssr.Location = new Point(1081, 696);
            linkLabellnssr.Name = "linkLabellnssr";
            linkLabellnssr.Size = new Size(62, 31);
            linkLabellnssr.TabIndex = 210;
            linkLabellnssr.TabStop = true;
            linkLabellnssr.Text = "神煞";
            linkLabellnssr.Visible = false;
            // 
            // linkLabellnssy
            // 
            linkLabellnssy.AutoSize = true;
            linkLabellnssy.BackColor = Color.Black;
            linkLabellnssy.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabellnssy.LinkColor = Color.Yellow;
            linkLabellnssy.Location = new Point(604, 694);
            linkLabellnssy.Name = "linkLabellnssy";
            linkLabellnssy.Size = new Size(62, 31);
            linkLabellnssy.TabIndex = 209;
            linkLabellnssy.TabStop = true;
            linkLabellnssy.Text = "神煞";
            linkLabellnssy.Visible = false;
            // 
            // linkLabellnssn
            // 
            linkLabellnssn.AutoSize = true;
            linkLabellnssn.BackColor = Color.Black;
            linkLabellnssn.Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            linkLabellnssn.LinkColor = Color.Yellow;
            linkLabellnssn.Location = new Point(120, 694);
            linkLabellnssn.Name = "linkLabellnssn";
            linkLabellnssn.Size = new Size(62, 31);
            linkLabellnssn.TabIndex = 208;
            linkLabellnssn.TabStop = true;
            linkLabellnssn.Text = "神煞";
            linkLabellnssn.Visible = false;
            // 
            // linkLabel3
            // 
            linkLabel3.AutoSize = true;
            linkLabel3.BackColor = Color.DodgerBlue;
            linkLabel3.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel3.LinkColor = Color.White;
            linkLabel3.Location = new Point(61, 538);
            linkLabel3.Name = "linkLabel3";
            linkLabel3.Size = new Size(33, 28);
            linkLabel3.TabIndex = 212;
            linkLabel3.TabStop = true;
            linkLabel3.Text = "合";
            // 
            // linkLabel7
            // 
            linkLabel7.AutoSize = true;
            linkLabel7.BackColor = Color.Green;
            linkLabel7.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel7.LinkColor = Color.White;
            linkLabel7.Location = new Point(62, 563);
            linkLabel7.Name = "linkLabel7";
            linkLabel7.Size = new Size(33, 28);
            linkLabel7.TabIndex = 213;
            linkLabel7.TabStop = true;
            linkLabel7.Text = "合";
            // 
            // linkLabel11
            // 
            linkLabel11.AutoSize = true;
            linkLabel11.BackColor = Color.Sienna;
            linkLabel11.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel11.LinkColor = Color.White;
            linkLabel11.Location = new Point(61, 594);
            linkLabel11.Name = "linkLabel11";
            linkLabel11.Size = new Size(33, 28);
            linkLabel11.TabIndex = 214;
            linkLabel11.TabStop = true;
            linkLabel11.Text = "合";
            // 
            // linkLabel14
            // 
            linkLabel14.AutoSize = true;
            linkLabel14.BackColor = Color.Sienna;
            linkLabel14.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel14.LinkColor = Color.White;
            linkLabel14.Location = new Point(542, 594);
            linkLabel14.Name = "linkLabel14";
            linkLabel14.Size = new Size(33, 28);
            linkLabel14.TabIndex = 217;
            linkLabel14.TabStop = true;
            linkLabel14.Text = "合";
            // 
            // linkLabel16
            // 
            linkLabel16.AutoSize = true;
            linkLabel16.BackColor = Color.Green;
            linkLabel16.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel16.LinkColor = Color.White;
            linkLabel16.Location = new Point(543, 563);
            linkLabel16.Name = "linkLabel16";
            linkLabel16.Size = new Size(33, 28);
            linkLabel16.TabIndex = 216;
            linkLabel16.TabStop = true;
            linkLabel16.Text = "合";
            // 
            // linkLabel18
            // 
            linkLabel18.AutoSize = true;
            linkLabel18.BackColor = Color.DodgerBlue;
            linkLabel18.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel18.LinkColor = Color.White;
            linkLabel18.Location = new Point(542, 538);
            linkLabel18.Name = "linkLabel18";
            linkLabel18.Size = new Size(33, 28);
            linkLabel18.TabIndex = 215;
            linkLabel18.TabStop = true;
            linkLabel18.Text = "合";
            // 
            // linkLabel19
            // 
            linkLabel19.AutoSize = true;
            linkLabel19.BackColor = Color.Sienna;
            linkLabel19.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel19.LinkColor = Color.White;
            linkLabel19.Location = new Point(1023, 594);
            linkLabel19.Name = "linkLabel19";
            linkLabel19.Size = new Size(33, 28);
            linkLabel19.TabIndex = 220;
            linkLabel19.TabStop = true;
            linkLabel19.Text = "合";
            // 
            // linkLabel34
            // 
            linkLabel34.AutoSize = true;
            linkLabel34.BackColor = Color.Green;
            linkLabel34.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel34.LinkColor = Color.White;
            linkLabel34.Location = new Point(1024, 563);
            linkLabel34.Name = "linkLabel34";
            linkLabel34.Size = new Size(33, 28);
            linkLabel34.TabIndex = 219;
            linkLabel34.TabStop = true;
            linkLabel34.Text = "合";
            // 
            // linkLabel39
            // 
            linkLabel39.AutoSize = true;
            linkLabel39.BackColor = Color.DodgerBlue;
            linkLabel39.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel39.LinkColor = Color.White;
            linkLabel39.Location = new Point(1023, 538);
            linkLabel39.Name = "linkLabel39";
            linkLabel39.Size = new Size(33, 28);
            linkLabel39.TabIndex = 218;
            linkLabel39.TabStop = true;
            linkLabel39.Text = "合";
            // 
            // linkLabel47
            // 
            linkLabel47.AutoSize = true;
            linkLabel47.BackColor = Color.Red;
            linkLabel47.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel47.LinkColor = Color.White;
            linkLabel47.Location = new Point(1506, 594);
            linkLabel47.Name = "linkLabel47";
            linkLabel47.Size = new Size(33, 28);
            linkLabel47.TabIndex = 223;
            linkLabel47.TabStop = true;
            linkLabel47.Text = "合";
            // 
            // linkLabel57
            // 
            linkLabel57.AutoSize = true;
            linkLabel57.BackColor = Color.Green;
            linkLabel57.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel57.LinkColor = Color.White;
            linkLabel57.Location = new Point(1507, 563);
            linkLabel57.Name = "linkLabel57";
            linkLabel57.Size = new Size(33, 28);
            linkLabel57.TabIndex = 222;
            linkLabel57.TabStop = true;
            linkLabel57.Text = "合";
            // 
            // linkLabel61
            // 
            linkLabel61.AutoSize = true;
            linkLabel61.BackColor = Color.Gold;
            linkLabel61.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel61.LinkColor = Color.Black;
            linkLabel61.Location = new Point(1038, 500);
            linkLabel61.Name = "linkLabel61";
            linkLabel61.Size = new Size(33, 28);
            linkLabel61.TabIndex = 221;
            linkLabel61.TabStop = true;
            linkLabel61.Text = "合";
            // 
            // linkLabel62
            // 
            linkLabel62.AutoSize = true;
            linkLabel62.BackColor = Color.Sienna;
            linkLabel62.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel62.LinkColor = Color.White;
            linkLabel62.Location = new Point(1042, 627);
            linkLabel62.Name = "linkLabel62";
            linkLabel62.Size = new Size(33, 28);
            linkLabel62.TabIndex = 226;
            linkLabel62.TabStop = true;
            linkLabel62.Text = "合";
            // 
            // linkLabel63
            // 
            linkLabel63.AutoSize = true;
            linkLabel63.BackColor = Color.Sienna;
            linkLabel63.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel63.LinkColor = Color.White;
            linkLabel63.Location = new Point(561, 627);
            linkLabel63.Name = "linkLabel63";
            linkLabel63.Size = new Size(33, 28);
            linkLabel63.TabIndex = 225;
            linkLabel63.TabStop = true;
            linkLabel63.Text = "合";
            // 
            // linkLabel64
            // 
            linkLabel64.AutoSize = true;
            linkLabel64.BackColor = Color.Sienna;
            linkLabel64.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel64.LinkColor = Color.White;
            linkLabel64.Location = new Point(80, 627);
            linkLabel64.Name = "linkLabel64";
            linkLabel64.Size = new Size(33, 28);
            linkLabel64.TabIndex = 224;
            linkLabel64.TabStop = true;
            linkLabel64.Text = "合";
            // 
            // linkLabel21
            // 
            linkLabel21.AutoSize = true;
            linkLabel21.BackColor = Color.Sienna;
            linkLabel21.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel21.LinkColor = Color.White;
            linkLabel21.Location = new Point(1166, 599);
            linkLabel21.Name = "linkLabel21";
            linkLabel21.Size = new Size(33, 28);
            linkLabel21.TabIndex = 233;
            linkLabel21.TabStop = true;
            linkLabel21.Text = "合";
            linkLabel21.Visible = false;
            // 
            // linkLabel65
            // 
            linkLabel65.AutoSize = true;
            linkLabel65.BackColor = Color.DodgerBlue;
            linkLabel65.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel65.LinkColor = Color.White;
            linkLabel65.Location = new Point(1166, 571);
            linkLabel65.Name = "linkLabel65";
            linkLabel65.Size = new Size(33, 28);
            linkLabel65.TabIndex = 232;
            linkLabel65.TabStop = true;
            linkLabel65.Text = "合";
            linkLabel65.Visible = false;
            // 
            // linkLabel66
            // 
            linkLabel66.AutoSize = true;
            linkLabel66.BackColor = Color.Sienna;
            linkLabel66.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel66.LinkColor = Color.White;
            linkLabel66.Location = new Point(685, 599);
            linkLabel66.Name = "linkLabel66";
            linkLabel66.Size = new Size(33, 28);
            linkLabel66.TabIndex = 231;
            linkLabel66.TabStop = true;
            linkLabel66.Text = "合";
            linkLabel66.Visible = false;
            // 
            // linkLabel67
            // 
            linkLabel67.AutoSize = true;
            linkLabel67.BackColor = Color.DodgerBlue;
            linkLabel67.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel67.LinkColor = Color.White;
            linkLabel67.Location = new Point(685, 571);
            linkLabel67.Name = "linkLabel67";
            linkLabel67.Size = new Size(33, 28);
            linkLabel67.TabIndex = 230;
            linkLabel67.TabStop = true;
            linkLabel67.Text = "合";
            linkLabel67.Visible = false;
            // 
            // linkLabel68
            // 
            linkLabel68.AutoSize = true;
            linkLabel68.BackColor = Color.Sienna;
            linkLabel68.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel68.LinkColor = Color.White;
            linkLabel68.Location = new Point(204, 599);
            linkLabel68.Name = "linkLabel68";
            linkLabel68.Size = new Size(33, 28);
            linkLabel68.TabIndex = 229;
            linkLabel68.TabStop = true;
            linkLabel68.Text = "合";
            linkLabel68.Visible = false;
            // 
            // linkLabel69
            // 
            linkLabel69.AutoSize = true;
            linkLabel69.BackColor = Color.DodgerBlue;
            linkLabel69.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel69.LinkColor = Color.White;
            linkLabel69.Location = new Point(204, 571);
            linkLabel69.Name = "linkLabel69";
            linkLabel69.Size = new Size(33, 28);
            linkLabel69.TabIndex = 228;
            linkLabel69.TabStop = true;
            linkLabel69.Text = "合";
            linkLabel69.Visible = false;
            // 
            // linkLabel70
            // 
            linkLabel70.AutoSize = true;
            linkLabel70.BackColor = Color.Sienna;
            linkLabel70.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel70.LinkColor = Color.White;
            linkLabel70.Location = new Point(1646, 595);
            linkLabel70.Name = "linkLabel70";
            linkLabel70.Size = new Size(33, 28);
            linkLabel70.TabIndex = 235;
            linkLabel70.TabStop = true;
            linkLabel70.Text = "合";
            linkLabel70.Visible = false;
            // 
            // linkLabel71
            // 
            linkLabel71.AutoSize = true;
            linkLabel71.BackColor = Color.DodgerBlue;
            linkLabel71.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel71.LinkColor = Color.White;
            linkLabel71.Location = new Point(1646, 567);
            linkLabel71.Name = "linkLabel71";
            linkLabel71.Size = new Size(33, 28);
            linkLabel71.TabIndex = 234;
            linkLabel71.TabStop = true;
            linkLabel71.Text = "合";
            linkLabel71.Visible = false;
            // 
            // linkLabel72
            // 
            linkLabel72.AutoSize = true;
            linkLabel72.BackColor = Color.Sienna;
            linkLabel72.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel72.LinkColor = Color.White;
            linkLabel72.Location = new Point(1646, 623);
            linkLabel72.Name = "linkLabel72";
            linkLabel72.Size = new Size(33, 28);
            linkLabel72.TabIndex = 239;
            linkLabel72.TabStop = true;
            linkLabel72.Text = "合";
            linkLabel72.Visible = false;
            // 
            // linkLabel73
            // 
            linkLabel73.AutoSize = true;
            linkLabel73.BackColor = Color.Sienna;
            linkLabel73.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel73.LinkColor = Color.White;
            linkLabel73.Location = new Point(1166, 627);
            linkLabel73.Name = "linkLabel73";
            linkLabel73.Size = new Size(33, 28);
            linkLabel73.TabIndex = 238;
            linkLabel73.TabStop = true;
            linkLabel73.Text = "合";
            linkLabel73.Visible = false;
            // 
            // linkLabel74
            // 
            linkLabel74.AutoSize = true;
            linkLabel74.BackColor = Color.Sienna;
            linkLabel74.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel74.LinkColor = Color.White;
            linkLabel74.Location = new Point(685, 627);
            linkLabel74.Name = "linkLabel74";
            linkLabel74.Size = new Size(33, 28);
            linkLabel74.TabIndex = 237;
            linkLabel74.TabStop = true;
            linkLabel74.Text = "合";
            linkLabel74.Visible = false;
            // 
            // linkLabel75
            // 
            linkLabel75.AutoSize = true;
            linkLabel75.BackColor = Color.Sienna;
            linkLabel75.Font = new Font("微软雅黑", 15.75F, FontStyle.Bold);
            linkLabel75.LinkColor = Color.White;
            linkLabel75.Location = new Point(204, 627);
            linkLabel75.Name = "linkLabel75";
            linkLabel75.Size = new Size(33, 28);
            linkLabel75.TabIndex = 236;
            linkLabel75.TabStop = true;
            linkLabel75.Text = "合";
            linkLabel75.Visible = false;
            // 
            // Form1
            // 
            AutoScaleMode = AutoScaleMode.None;
            BackColor = Color.DimGray;
            ClientSize = new Size(1904, 1011);
            Controls.Add(linkLabel72);
            Controls.Add(linkLabel73);
            Controls.Add(linkLabel74);
            Controls.Add(linkLabel75);
            Controls.Add(linkLabel70);
            Controls.Add(linkLabel71);
            Controls.Add(linkLabel21);
            Controls.Add(linkLabel65);
            Controls.Add(linkLabel66);
            Controls.Add(linkLabel67);
            Controls.Add(linkLabel68);
            Controls.Add(linkLabel69);
            Controls.Add(linkLabel62);
            Controls.Add(linkLabel63);
            Controls.Add(linkLabel64);
            Controls.Add(linkLabel47);
            Controls.Add(linkLabel57);
            Controls.Add(linkLabel61);
            Controls.Add(linkLabel19);
            Controls.Add(linkLabel34);
            Controls.Add(linkLabel39);
            Controls.Add(linkLabel14);
            Controls.Add(linkLabel16);
            Controls.Add(linkLabel18);
            Controls.Add(linkLabel11);
            Controls.Add(linkLabel7);
            Controls.Add(linkLabel3);
            Controls.Add(linkLabellnsss);
            Controls.Add(linkLabellnssr);
            Controls.Add(linkLabellnssy);
            Controls.Add(linkLabellnssn);
            Controls.Add(linkLabelsdzss2);
            Controls.Add(linkLabelrdzss2);
            Controls.Add(linkLabelydzss2);
            Controls.Add(linkLabelndzss2);
            Controls.Add(checkBoxln);
            Controls.Add(linkLabel28);
            Controls.Add(numericUpDownhour);
            Controls.Add(numericUpDownday);
            Controls.Add(numericUpDownmonth);
            Controls.Add(numericUpDownyear);
            Controls.Add(checkBox1);
            Controls.Add(button59);
            Controls.Add(linkLabel25);
            Controls.Add(button56);
            Controls.Add(button54);
            Controls.Add(button52);
            Controls.Add(button55);
            Controls.Add(button57);
            Controls.Add(button58);
            Controls.Add(button61);
            Controls.Add(button62);
            Controls.Add(button63);
            Controls.Add(button65);
            Controls.Add(button34);
            Controls.Add(button35);
            Controls.Add(button36);
            Controls.Add(button37);
            Controls.Add(button26);
            Controls.Add(button27);
            Controls.Add(button28);
            Controls.Add(button29);
            Controls.Add(button30);
            Controls.Add(button31);
            Controls.Add(button32);
            Controls.Add(button33);
            Controls.Add(button25);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(label1);
            Controls.Add(linkLabel7hff);
            Controls.Add(richTextBox1);
            Controls.Add(linkLabel60);
            Controls.Add(linkLabel59);
            Controls.Add(linkLabel58);
            Controls.Add(linkLabelsdzss1);
            Controls.Add(linkLabel56);
            Controls.Add(linkLabel55);
            Controls.Add(linkLabel54);
            Controls.Add(linkLabel53);
            Controls.Add(linkLabel52);
            Controls.Add(linkLabel51);
            Controls.Add(linkLabel50);
            Controls.Add(linkLabel49);
            Controls.Add(linkLabel48);
            Controls.Add(linkLabelrdzss1);
            Controls.Add(linkLabel46);
            Controls.Add(linkLabel45);
            Controls.Add(linkLabel44);
            Controls.Add(linkLabel43);
            Controls.Add(linkLabel42);
            Controls.Add(linkLabel41);
            Controls.Add(linkLabel40);
            Controls.Add(linkLabelydzss1);
            Controls.Add(linkLabel38);
            Controls.Add(linkLabel37);
            Controls.Add(linkLabel36);
            Controls.Add(linkLabel35);
            Controls.Add(linkLabelndzss1);
            Controls.Add(linkLabel33);
            Controls.Add(linkLabel32);
            Controls.Add(linkLabel31);
            Controls.Add(linkLabel30);
            Controls.Add(linkLabel29);
            Controls.Add(linkLabelscs);
            Controls.Add(linkLabel27);
            Controls.Add(linkLabel26);
            Controls.Add(linkLabelstgss);
            Controls.Add(linkLabel24);
            Controls.Add(linkLabel23);
            Controls.Add(linkLabel22);
            Controls.Add(linkLabelrcs);
            Controls.Add(linkLabel20);
            Controls.Add(linkLabelrtgss);
            Controls.Add(linkLabel17);
            Controls.Add(linkLabel15);
            Controls.Add(linkLabelycs);
            Controls.Add(linkLabel13);
            Controls.Add(linkLabel12);
            Controls.Add(linkLabelytgss);
            Controls.Add(linkLabel10);
            Controls.Add(linkLabel9);
            Controls.Add(linkLabel8);
            Controls.Add(linkLabencs);
            Controls.Add(linkLabel6);
            Controls.Add(linkLabel5);
            Controls.Add(linkLabel4);
            Controls.Add(linkLabelntgss);
            Controls.Add(linkLabel2);
            Controls.Add(linkLabel1);
            Controls.Add(buttongz);
            Controls.Add(buttonhuo);
            Controls.Add(buttonmu);
            Controls.Add(buttonshui);
            Controls.Add(buttontu);
            Controls.Add(buttonjin);
            Controls.Add(buttongj);
            Controls.Add(buttonp);
            Controls.Add(button24);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(buttonsg);
            Controls.Add(buttonrg);
            Controls.Add(buttonyg);
            Controls.Add(buttonng);
            Controls.Add(dateTimePicker1);
            Controls.Add(radioButtonll);
            Controls.Add(radioButtonvv);
            Controls.Add(comboBoxng);
            Controls.Add(comboBoxyg);
            Controls.Add(comboBoxrg);
            Controls.Add(comboBoxsg);
            Controls.Add(comboBoxnz);
            Controls.Add(comboBoxyz);
            Controls.Add(comboBoxrz);
            Controls.Add(comboBoxsz);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(buttonrz);
            Controls.Add(button4);
            Controls.Add(buttonsz);
            Controls.Add(buttonyz);
            Controls.Add(buttonnz);
            Font = new Font("微软雅黑", 18F, FontStyle.Bold);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "八字排盘工具v96-杜净隆 作品";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)numericUpDownyear).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownmonth).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownday).EndInit();
            ((System.ComponentModel.ISupportInitialize)numericUpDownhour).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button buttonnz;
        private Button buttonyz;
        private Button buttonsz;
        private Button button4;
        private Button buttonrz;
        private Button button6;
        private Button button7;
        private Button button8;
        private ComboBox comboBoxsz;
        private ComboBox comboBoxrz;
        private ComboBox comboBoxyz;
        private ComboBox comboBoxnz;
        private ComboBox comboBoxsg;
        private ComboBox comboBoxrg;
        private ComboBox comboBoxyg;
        private ComboBox comboBoxng;
        private RadioButton radioButtonvv;
        private RadioButton radioButtonll;
        private DateTimePicker dateTimePicker1;
        private Button buttonng;
        private Button buttonyg;
        private Button buttonrg;
        private Button buttonsg;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private Button buttonp;
        private Button buttongj;
        private Button buttonjin;
        private Button buttontu;
        private Button buttonshui;
        private Button buttonmu;
        private Button buttonhuo;
        private Button buttongz;
        private LinkLabel linkLabel1;
        private LinkLabel linkLabel2;
        private LinkLabel linkLabelntgss;
        private LinkLabel linkLabel4;
        private LinkLabel linkLabel5;
        private LinkLabel linkLabel6;
        private LinkLabel linkLabencs;
        private LinkLabel linkLabel8;
        private LinkLabel linkLabel9;
        private LinkLabel linkLabel10;
        private LinkLabel linkLabelytgss;
        private LinkLabel linkLabel12;
        private LinkLabel linkLabel13;
        private LinkLabel linkLabelycs;
        private LinkLabel linkLabel15;
        private LinkLabel linkLabel17;
        private LinkLabel linkLabelrtgss;
        private LinkLabel linkLabel20;
        private LinkLabel linkLabelrcs;
        private LinkLabel linkLabel22;
        private LinkLabel linkLabel23;
        private LinkLabel linkLabel24;
        private LinkLabel linkLabelstgss;
        private LinkLabel linkLabel26;
        private LinkLabel linkLabel27;
        private LinkLabel linkLabelscs;
        private LinkLabel linkLabel29;
        private LinkLabel linkLabel30;
        private LinkLabel linkLabel31;
        private LinkLabel linkLabel32;
        private LinkLabel linkLabel33;
        private LinkLabel linkLabelndzss1;
        private LinkLabel linkLabel35;
        private LinkLabel linkLabel36;
        private LinkLabel linkLabel37;
        private LinkLabel linkLabel38;
        private LinkLabel linkLabelydzss1;
        private LinkLabel linkLabel40;
        private LinkLabel linkLabel41;
        private LinkLabel linkLabel42;
        private LinkLabel linkLabel43;
        private LinkLabel linkLabel44;
        private LinkLabel linkLabel45;
        private LinkLabel linkLabel46;
        private LinkLabel linkLabelrdzss1;
        private LinkLabel linkLabel48;
        private LinkLabel linkLabel49;
        private LinkLabel linkLabel50;
        private LinkLabel linkLabel51;
        private LinkLabel linkLabel52;
        private LinkLabel linkLabel53;
        private LinkLabel linkLabel54;
        private LinkLabel linkLabel55;
        private LinkLabel linkLabel56;
        private LinkLabel linkLabelsdzss1;
        private LinkLabel linkLabel58;
        private LinkLabel linkLabel59;
        private LinkLabel linkLabel60;
        private RichTextBox richTextBox1;
        private LinkLabel linkLabel7hff;
        private System.Windows.Forms.Timer timer1;
        private Label label1;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button25;
        private Button button26;
        private Button button27;
        private Button button28;
        private Button button29;
        private Button button30;
        private Button button31;
        private Button button32;
        private Button button33;
        private Button button34;
        private Button button35;
        private Button button36;
        private Button button37;
        private Button button52;
        private Button button55;
        private Button button57;
        private Button button58;
        private Button button61;
        private Button button62;
        private Button button63;
        private Button button65;
        private Button button54;
        private Button button56;
        private LinkLabel linkLabel25;
        private Button button59;
        private CheckBox checkBox1;
        private NumericUpDown numericUpDownyear;
        private NumericUpDown numericUpDownmonth;
        private NumericUpDown numericUpDownday;
        private NumericUpDown numericUpDownhour;
        private LinkLabel linkLabel28;
        private CheckBox checkBoxln;
        private LinkLabel linkLabelsdzss2;
        private LinkLabel linkLabelrdzss2;
        private LinkLabel linkLabelydzss2;
        private LinkLabel linkLabelndzss2;
        private LinkLabel linkLabellnsss;
        private LinkLabel linkLabellnssr;
        private LinkLabel linkLabellnssy;
        private LinkLabel linkLabellnssn;
        private LinkLabel linkLabel3;
        private LinkLabel linkLabel7;
        private LinkLabel linkLabel11;
        private LinkLabel linkLabel14;
        private LinkLabel linkLabel16;
        private LinkLabel linkLabel18;
        private LinkLabel linkLabel19;
        private LinkLabel linkLabel34;
        private LinkLabel linkLabel39;
        private LinkLabel linkLabel47;
        private LinkLabel linkLabel57;
        private LinkLabel linkLabel61;
        private LinkLabel linkLabel62;
        private LinkLabel linkLabel63;
        private LinkLabel linkLabel64;
        private LinkLabel linkLabel21;
        private LinkLabel linkLabel65;
        private LinkLabel linkLabel66;
        private LinkLabel linkLabel67;
        private LinkLabel linkLabel68;
        private LinkLabel linkLabel69;
        private LinkLabel linkLabel70;
        private LinkLabel linkLabel71;
        private LinkLabel linkLabel72;
        private LinkLabel linkLabel73;
        private LinkLabel linkLabel74;
        private LinkLabel linkLabel75;
    }
}